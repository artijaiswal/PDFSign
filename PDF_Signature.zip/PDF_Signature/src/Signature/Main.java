package Signature;

import java.awt.Color;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateExpiredException;
import java.security.cert.CertificateNotYetValidException;
import java.security.cert.X509Certificate;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.common.PDStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.form.PDFormXObject;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceDictionary;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAppearanceStream;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.PDSignature;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.SignatureInterface;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.SignatureOptions;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.visible.PDVisibleSigProperties;
import org.apache.pdfbox.pdmodel.interactive.digitalsignature.visible.PDVisibleSignDesigner;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDField;
import org.apache.pdfbox.pdmodel.interactive.form.PDSignatureField;
import org.apache.pdfbox.util.Matrix;
import org.bouncycastle.asn1.x500.RDN;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.asn1.x500.style.BCStyle;
import org.bouncycastle.asn1.x500.style.IETFUtils;
import org.bouncycastle.cert.jcajce.JcaCertStore;
import org.bouncycastle.cms.CMSException;
import org.bouncycastle.cms.CMSSignedData;
import org.bouncycastle.cms.CMSSignedDataGenerator;
import org.bouncycastle.cms.jcajce.JcaSignerInfoGeneratorBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.bouncycastle.operator.jcajce.JcaDigestCalculatorProviderBuilder;

import sun.security.pkcs11.SunPKCS11;

public class Main implements SignatureInterface {


	private PDVisibleSignDesigner visibleSignDesigner;
	private final PDVisibleSigProperties visibleSignatureProperties = new PDVisibleSigProperties();
	private String CertName;
	private X509Certificate cert;
	private PrivateKey pk;
	private Certificate[] chain;
	private boolean certificateValidation;

	
	public String getCertName() {
		return CertName;
	}

	public void setCertName(String certName) {
		CertName = certName;
	}

	public Certificate[] getChain() {
		return chain;
	}

	public boolean isCertificateValidation() {
		return certificateValidation;
	}

	public void setCertificateValidation(boolean certificateValidation) {
		this.certificateValidation = certificateValidation;
	}

	public void setChain(Certificate[] chain) {
		this.chain = chain;
	}

	public X509Certificate getCert() {
		return cert;
	}

	public PrivateKey getPk() {
		return pk;
	}

	public void setPk(PrivateKey pk) {
		this.pk = pk;
	}

	public void setCert(X509Certificate cert) {
		this.cert = cert;
	}

	public static void main(String[] args) throws IOException, GeneralSecurityException {

		String userFile = "C:\\Users\\arti jaiswal\\Desktop/IN/GST Invoice-NDO4257.pdf";
		String userFile_signed = "C:\\Users\\arti jaiswal\\Desktop/OUT/";

		Main m = new Main();
		m.SetCertificateDetails();
		//m.setVisibleSignatureProperties("name", "location", "Security", 0, page, true);
		File inFile = new File(userFile);
		inFile.getName();
		userFile_signed = userFile_signed+inFile.getName();
		m.signDetached(inFile, userFile_signed);
	}

	public void Main()
	{
		try {
			SetCertificateDetails();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void SignatureProcess(String inFile)
	{
		String userFile = "C:\\Users\\arti jaiswal\\Desktop/IN/GST Invoice-NDO4257.pdf";
		String userFile_signed = "C:\\Users\\arti jaiswal\\Desktop/OUT/";
	}
	public void SetCertificateDetails() throws IOException {
		try {
			
//			 String pkcs11Config = "name=eToken\nlibrary=C:\\Windows\\System32\\eps2003csp11v2.dll";
//			    java.io.ByteArrayInputStream pkcs11ConfigStream = new java.io.ByteArrayInputStream(pkcs11Config.getBytes());
//			    sun.security.pkcs11.SunPKCS11 providerPKCS11 = new sun.security.pkcs11.SunPKCS11(pkcs11ConfigStream);
//			    java.security.Security.addProvider(providerPKCS11);
			
			//String configPath = new File("src/Signature")
			SunPKCS11 providerPKCS11 = new SunPKCS11("E:\\JavaWorkSpace\\PDF_Signature\\src\\Signature\\pkcs11.cfg");
			java.security.Security.addProvider(providerPKCS11);

			// Get provider KeyStore and login with PIN
			String pin = "12345678";
			java.security.KeyStore keyStore = java.security.KeyStore.getInstance("PKCS11", providerPKCS11);
			keyStore.load(null, pin.toCharArray());
			// Enumerate items (certificates and private keys) in the KeyStore
			java.util.Enumeration<String> aliases = keyStore.aliases();
			String alias = null;
			while (aliases.hasMoreElements()) {
				alias = aliases.nextElement();
				break;
			}
			System.out.println("alias "+ alias);
			PrivateKey pk = (PrivateKey) keyStore.getKey(alias, "12345678".toCharArray());
			setPk(pk);
			Certificate[] chain = keyStore.getCertificateChain(alias);
			setChain(chain);
			Certificate certificate = chain[0];

			X509Certificate cert = (X509Certificate) certificate;
			setCertName(cert.getSubjectX500Principal().getName());
			setCert(cert);
			cert.checkValidity();
			certificateValidation = true;
			
		} catch (CertificateExpiredException ex) {
			certificateValidation = false;
			System.out.print("Get cert validation " + certificateValidation);
		} catch (CertificateNotYetValidException e) {
			certificateValidation = false;
			System.out.print("Get cert validation " + certificateValidation);
		}

		catch (GeneralSecurityException e) {
			throw new IOException(e);
		}

	}

	public void signDetached(File file) throws IOException {
		// signDetached(file, file);
	}

	/**
	 * Signs the given PDF file.
	 * 
	 * @param inFile
	 *            input PDF file
	 * @param outFile
	 *            output PDF file
	 * @throws IOException
	 *             if the input file could not be read
	 */
	public void signDetached(File inFile, String outFile) throws IOException {
		if (inFile == null || !inFile.exists()) {
			throw new FileNotFoundException("Document for signing does not exist");
		}
		System.out.println("Sign started");
		FileOutputStream fos = new FileOutputStream(outFile);

		// sign
		PDDocument doc = PDDocument.load(inFile);
		signDetached(doc, fos);
		doc.close();
		fos.close();
	}

	public void signDetached(PDDocument document, OutputStream output) throws IOException {
		System.out.println("signDetached");
		// create signature dictionary
		PDSignature signature = new PDSignature();

		PDAcroForm acroForm = document.getDocumentCatalog().getAcroForm();

		if (acroForm != null && acroForm.getNeedAppearances()) {
			// PDFBOX-3738 NeedAppearances true results in visible signature
			// becoming invisible
			// with Adobe Reader
			if (acroForm.getFields().isEmpty()) {
				// we can safely delete it if there are no fields
				acroForm.getCOSObject().removeItem(COSName.NEED_APPEARANCES);
				// note that if you've set MDP permissions, the removal of this
				// item
				// may result in Adobe Reader claiming that the document has
				// been changed.
				// and/or that field content won't be displayed properly.
				// ==> decide what you prefer and adjust your code accordingly.
			} else {
				System.out.println("/NeedAppearances is set, signature may be ignored by Adobe Reader");
			}
		}
		
		Rectangle2D humanRect = new Rectangle2D.Float(400, 845, 170, 30);
		
		PDRectangle rect = createSignatureRectangle(document, humanRect);
		signature.setFilter(PDSignature.FILTER_ADOBE_PPKLITE);
		signature.setSubFilter(PDSignature.SUBFILTER_ADBE_PKCS7_DETACHED);
		signature.setSignDate(Calendar.getInstance());

		SignatureOptions signatureOptions = new SignatureOptions();

		// Size can vary, but should be enough for purpose.
		// signatureOptions.setPreferredSignatureSize(SignatureOptions.DEFAULT_SIGNATURE_SIZE
		// * 2);
		
		// check page number 
		int pageCount= document.getNumberOfPages()-1;
		signatureOptions.setVisualSignature(createVisualSignatureTemplate(document, pageCount, rect, signature));
		signatureOptions.setPage(pageCount);
		// register signature dictionary and sign interface
		document.addSignature(signature, this, signatureOptions);
		System.out.println("Adding signature options");
		// write incremental (only for signing purpose)
		document.saveIncremental(output);
		document.close();
		IOUtils.closeQuietly(signatureOptions);
	}

	@Override
	public byte[] sign(InputStream content) throws IOException {
		// TODO Auto-generated method stub
		System.out.println("Under override method");
		try {

			CMSSignedDataGenerator gen = new CMSSignedDataGenerator();
System.out.println("Private key check "+getPk());
			ContentSigner sha1Signer = new JcaContentSignerBuilder("SHA256withRSA").build(getPk());
			gen.addSignerInfoGenerator(
					new JcaSignerInfoGeneratorBuilder(new JcaDigestCalculatorProviderBuilder().build())
							.build(sha1Signer, getCert()));
			gen.addCertificates(new JcaCertStore(Arrays.asList(getChain())));
			CMSProcessableInputStream msg = new CMSProcessableInputStream(content);
			CMSSignedData signedData = gen.generate(msg, false);

			return signedData.getEncoded();
		} catch (GeneralSecurityException e) {
			throw new IOException(e);
		} catch (CMSException e) {
			throw new IOException(e);
		} catch (OperatorCreationException e) {
			throw new IOException(e);
		}
	}

	

	
	/**
	 * Set visible signature properties for new signature fields.
	 * 
	 * @param name
	 * @param location
	 * @param reason
	 * @param preferredSize
	 * @param page
	 * @param visualSignEnabled
	 */
	public void setVisibleSignatureProperties(String name, String location, String reason, int preferredSize, int page,
			boolean visualSignEnabled) {
		visibleSignatureProperties.signerName(name).signerLocation(location).signatureReason(reason)
				.preferredSize(preferredSize).page(page).visualSignEnabled(visualSignEnabled)
				.setPdVisibleSignature(visibleSignDesigner);
	}


	private InputStream createVisualSignatureTemplate(PDDocument srcDoc, int pageNum, PDRectangle rect,
			PDSignature signature) throws IOException {
		PDDocument doc = new PDDocument();

		PDPage page = new PDPage(srcDoc.getPage(pageNum).getMediaBox());
		doc.addPage(page);
		PDAcroForm acroForm = new PDAcroForm(doc);
		doc.getDocumentCatalog().setAcroForm(acroForm);
		PDSignatureField signatureField = new PDSignatureField(acroForm);
		PDAnnotationWidget widget = signatureField.getWidgets().get(0);
		List<PDField> acroFormFields = acroForm.getFields();
		acroForm.setSignaturesExist(true);
		acroForm.setAppendOnly(true);
		acroForm.getCOSObject().setDirect(true);
		acroFormFields.add(signatureField);

		widget.setRectangle(rect);

		// from PDVisualSigBuilder.createHolderForm()
		PDStream stream = new PDStream(doc);
		PDFormXObject form = new PDFormXObject(stream);
		PDResources res = new PDResources();
		form.setResources(res);
		form.setFormType(1);
		PDRectangle bbox = new PDRectangle(rect.getWidth(), rect.getHeight());
		float height = bbox.getHeight();
		Matrix initialScale = null;
		switch (srcDoc.getPage(pageNum).getRotation()) {
		case 90:
			form.setMatrix(AffineTransform.getQuadrantRotateInstance(1));
			initialScale = Matrix.getScaleInstance(bbox.getWidth() / bbox.getHeight(),
					bbox.getHeight() / bbox.getWidth());
			height = bbox.getWidth();
			break;
		case 180:
			form.setMatrix(AffineTransform.getQuadrantRotateInstance(2));
			break;
		case 270:
			form.setMatrix(AffineTransform.getQuadrantRotateInstance(3));
			initialScale = Matrix.getScaleInstance(bbox.getWidth() / bbox.getHeight(),
					bbox.getHeight() / bbox.getWidth());
			height = bbox.getWidth();
			break;
		case 0:
		default:
			break;
		}
		form.setBBox(bbox);
		PDFont font = PDType1Font.HELVETICA;

		// from PDVisualSigBuilder.createAppearanceDictionary()
		PDAppearanceDictionary appearance = new PDAppearanceDictionary();
		appearance.getCOSObject().setDirect(true);
		PDAppearanceStream appearanceStream = new PDAppearanceStream(form.getCOSObject());
		appearance.setNormalAppearance(appearanceStream);
		widget.setAppearance(appearance);

		PDPageContentStream cs = new PDPageContentStream(doc, appearanceStream);

		// for 90° and 270° scale ratio of width / height
		// not really sure about this
		// why does scale have no effect when done in the form matrix???
		if (initialScale != null) {
			cs.transform(initialScale);
		}

		// show background (just for debugging, to see the rect size + position)
		// cs.setNonStrokingColor(Color.yellow);
		// cs.addRect(-5000, -5000, 10000, 10000);
		// cs.fill();

		// show background image
		// save and restore graphics if the image is too large and needs to be
		// scaled
		File imageFile =  new File("C:\\Users\\arti jaiswal\\Desktop\\download.png");
		if (!certificateValidation) {
			imageFile = new File("C:\\Users\\arti jaiswal\\Desktop\\question.png");
		}
		cs.saveGraphicsState();
		cs.transform(Matrix.getScaleInstance(0.25f, 0.25f));
		PDImageXObject img = PDImageXObject.createFromFileByExtension(imageFile, doc);
		cs.drawImage(img, 0, 0);
		cs.restoreGraphicsState();

		// show text
		float fontSize = 6;
		float leading = fontSize * 1.5f;
		cs.beginText();
		cs.setFont(font, fontSize);
		cs.setNonStrokingColor(Color.black);
		cs.newLineAtOffset(fontSize+2, height - leading);
		cs.setLeading(leading);

		X500Name x500Name = new X500Name(getCertName());
		RDN cn = x500Name.getRDNs(BCStyle.CN)[0];
		String name = IETFUtils.valueToString(cn.getFirst().getValue());

		String date = signature.getSignDate().getTime().toString();

		cs.showText("Digitally signed by " + name);
		cs.newLine();
		cs.showText("Date: " + date);
		cs.endText();

		cs.close();

		// no need to set annotations and /P entry
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		doc.save(baos);
		doc.close();
		return new ByteArrayInputStream(baos.toByteArray());
	}

	private PDRectangle createSignatureRectangle(PDDocument doc, Rectangle2D humanRect) {
		float x = (float) humanRect.getX();
		float y = (float) humanRect.getY();
		float width = (float) humanRect.getWidth();
		float height = (float) humanRect.getHeight();
		PDPage page = doc.getPage(0);
		PDRectangle pageRect = page.getCropBox();
		PDRectangle rect = new PDRectangle();
		// signing should be at the same position regardless of page rotation.
		switch (page.getRotation()) {
		case 90:
			rect.setLowerLeftY(x);
			rect.setUpperRightY(x + width);
			rect.setLowerLeftX(y);
			rect.setUpperRightX(y + height);
			break;
		case 180:
			rect.setUpperRightX(pageRect.getWidth() - x);
			rect.setLowerLeftX(pageRect.getWidth() - x - width);
			rect.setLowerLeftY(y);
			rect.setUpperRightY(y + height);
			break;
		case 270:
			rect.setLowerLeftY(pageRect.getHeight() - x - width);
			rect.setUpperRightY(pageRect.getHeight() - x);
			rect.setLowerLeftX(pageRect.getWidth() - y - height);
			rect.setUpperRightX(pageRect.getWidth() - y);
			break;
		case 0:
		default:
			rect.setLowerLeftX(x);
			rect.setUpperRightX(x + width);
			rect.setLowerLeftY(pageRect.getHeight() - y - height);
			rect.setUpperRightY(pageRect.getHeight() - y);
			break;
		}
		return rect;
	}

}
